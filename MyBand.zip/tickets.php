<?php
  include 'header.php';
 ?>
    <nav class="navigatie">
      <a href="index.php" class="sitemix"><b>Sitemix</b></a>
      <a href="index.php" class="item">home</a>
      <a href="tickets.php" class="item">tickets</a>
      <a href="foto.php" class="item">foto's</a>
      <a href="nieuws.php" class="item">nieuws</a>
      <a href="contact.php" class="item">contact</a>
    </nav>
  <div class="tvak">
  </div>
  <?php
    include 'footer.php';
   ?>
