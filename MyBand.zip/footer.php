<?php
  include 'dbh.php';
 ?>

<div class="footer">
  <p class="rico">Rico Dijkstra ©</p><div class="lijn"></div>
  <img src="img/c.png" alt="Copyright" class="copyright">
  <img src="img/instagram.png" alt="instagram" class="ig">
    <img src="img/facebook.png" alt="facebook" class="fb">
      <img src="img/youtube.png" alt="youtube" class="yt">
        <img src="img/twitter.png" alt="twitter" class="tt">
        <img src="img/soundcloud.png" alt="soundcloud" class="sc">
</div>
  </body>
</html>
